package com.wellsfargo.counselor.entity;

import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Portfolio {
    public class Portfolio {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        private String name;

        @ManyToOne
        @JoinColumn(name = "client_id")
        private Client client;

        // Default constructor
        public Portfolio() {
        }

        // Constructor with parameters
        public Portfolio(String name, Client client) {
            this.name = name;
            this.client = client;
        }
}
