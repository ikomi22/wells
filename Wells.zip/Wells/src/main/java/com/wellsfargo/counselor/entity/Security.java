package com.wellsfargo.counselor.entity;

import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Security {
    public class Security {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        private String name;
        private String category;
        private String purchaseDate;
        private double purchasePrice;
        private int quantity;

        @ManyToOne
        @JoinColumn(name = "portfolio_id")
        private Portfolio portfolio;

        // Default constructor
        public Security() {
        }

        // Constructor with parameters
        public Security(String name, String category, String purchaseDate, double purchasePrice, int quantity, Portfolio portfolio) {
            this.name = name;
            this.category = category;
            this.purchaseDate = purchaseDate;
            this.purchasePrice = purchasePrice;
            this.quantity = quantity;
            this.portfolio = portfolio;
        }
}
